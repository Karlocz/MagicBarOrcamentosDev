# Atualização comercial e agenda de degustação

## Objetivo
Ampliar o aplicativo existente sem recriar orçamento, frete, agenda, autenticação ou links públicos. A mesma disponibilidade e as mesmas reservas alimentarão o orçamento e a nova página `/degustacao`.

## Implementação

### 1. Agenda única e reservas de 1 hora
- Manter `tasting_availability` e `tasting_appointments` como fonte única.
- Fixar a duração comercial em 60 minutos e gerar horários que terminem dentro da janela configurada, incluindo janelas que encerram à `00:00`.
- Exibir todos os horários da data selecionada com estados “Disponível” e “Indisponível”; bloqueios administrativos, reservas ativas e reservas feitas pelos dois caminhos terão o mesmo efeito.
- Expandir os estados da degustação para: pendente de pagamento, agendado, confirmado, realizado, cancelado e não compareceu; pagamento fica separado em pendente ou pago.
- Criar reserva temporária de 30 minutos para pagamentos pendentes. Consultas e novas reservas liberarão automaticamente retenções vencidas, preservando o registro no histórico.
- Cancelamentos liberarão o horário sem apagar o agendamento.

### 2. Página pública `/degustacao`
- Criar uma página pública responsiva com metadados próprios, usando as mesmas funções e dados da agenda atual.
- Permitir selecionar data e horário, informar nome, WhatsApp e pessoas, visualizar valor por pessoa e total, reservar e abrir o link de pagamento existente.
- Como não existe confirmação automática de pagamento, a reserva ficará com pagamento pendente até confirmação manual do administrador.
- Após confirmação real, exibir data, horário, duração, participantes, valores e endereço configurado da degustação.
- Oferecer mensagem de WhatsApp da degustação com dados e estados reais; incluir o link do orçamento quando houver vínculo.

### 3. Experiência de degustação dentro do orçamento
- Extrair a seleção/agendamento para um componente compartilhado com `/degustacao`, evitando lógica duplicada.
- Manter o fluxo e todos os campos atuais do orçamento.
- Atualizar o texto para “Agende sua degustação”, com experiência de 1 hora, datas destacadas e alto contraste conforme solicitado.
- Não tratar clique em “Pagar” como pagamento confirmado.
- Completar WhatsApp do orçamento com duração e estados da degustação.
- Adicionar “Compartilhar orçamento” usando `navigator.share` e fallback de cópia do link público existente.

### 4. Configurações e painel de degustações
- Adicionar endereço próprio da degustação: endereço, número, complemento, bairro, cidade, estado e CEP, separado da origem do frete.
- Manter datas administráveis e permitir editar início/fim por data, ativar/desativar, bloquear horários e remover datas sem reservas relacionadas.
- Mostrar link da agenda com “Copiar link” e “Compartilhar agenda”.
- Adicionar filtros por data, pagamento e estado; indicadores de próximas, pendentes, pagas, confirmadas, realizadas e canceladas.
- Mostrar cliente, WhatsApp, data, horário, pessoas, total e estados.
- Permitir marcar pagamento pendente/pago e alterar todos os estados solicitados; cancelamento terá confirmação explícita.

### 5. Gestão de orçamentos
- Adicionar arquivamento reversível, preservando banco, histórico, link público e degustações relacionadas.
- Não oferecer exclusão física enquanto houver risco de quebrar relações; arquivamento será a ação segura.
- Adicionar filtros Todos/Ativos/Arquivados e busca por contratante, nomes dos homenageados, CPF e data do evento.
- Trocar o carregamento fixo por paginação no servidor, mantendo a listagem administrativa protegida.

### 6. Trajeto e compartilhamento
- Preservar integralmente o cálculo atual de rota e frete.
- Adicionar “Ver trajeto no Google Maps” apenas para visualização, usando origem configurada e destino do evento, sem alterar o cálculo existente.

## Alterações no banco
Uma migration incremental e segura irá:
- adicionar endereço da degustação às configurações;
- adicionar duração, vencimento da reserva e estados ampliados aos agendamentos, migrando os estados atuais sem perda;
- adaptar a proteção de conflito para considerar apenas reservas ativas e não vencidas por meio do fluxo transacional de reserva;
- adicionar `archived_at` aos orçamentos;
- preservar tabelas, registros, tokens públicos, vínculos, permissões e políticas atuais.

A migration incluirá apenas alterações estruturais. Nenhuma tabela existente será duplicada ou apagada.

## Segurança e regras preservadas
- Escritas públicas continuarão exclusivamente por funções do servidor com validação e valores recalculados.
- Administração continuará restrita a administradores autenticados.
- CPF continuará mascarado no orçamento público.
- Drink, preços, taças/copos, adultos/crianças, horários do evento, rascunho, WhatsApp, token público, frete, São Paulo, distância máxima e rota real não serão substituídos.

## Validação final
- Verificar TypeScript, compilação, imports, rotas públicas/protegidas e aplicação da migration.
- Fazer somente verificações básicas dos fluxos alterados, sem bateria extensa de testes ou mudanças do Prompt 2.

## Configurações manuais após a atualização
- Preencher o endereço da degustação.
- Manter/preencher o link de pagamento, chave Pix, QR Code e WhatsApp de comprovantes.
- Como não há webhook de pagamento existente, pagamentos continuarão dependendo de confirmação manual no painel.
