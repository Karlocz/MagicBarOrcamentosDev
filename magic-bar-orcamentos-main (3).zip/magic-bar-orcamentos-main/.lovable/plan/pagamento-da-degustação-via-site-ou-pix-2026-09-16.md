# Pagamento da degustação via site ou Pix

## Objetivo
Ajustar somente o pagamento da degustação para oferecer pagamento pelo site e Pix, mantendo a reserva temporária atual de 30 minutos e sem criar outra integração ou migration.

## Implementação
- Criar o produto de degustação no ambiente de teste, a R$ 20,00 por pessoa, com quantidade de 1 a 50 pessoas e classificação fiscal adequada ao serviço.
- Reutilizar a integração de pagamentos já habilitada para abrir o checkout incorporado, vinculando cada sessão à reserva temporária criada.
- Manter a reserva com pagamento pendente ao apenas abrir o checkout; somente uma confirmação assinada do provedor marcará pagamento como pago e degustação como confirmada.
- Adicionar o manipulador público de confirmação de pagamento no endereço já registrado pela integração, validando a assinatura e atualizando somente a reserva correspondente.
- Exibir as duas escolhas após reservar: “💳 Pagar pelo site” e “📱 Pagar via Pix”.
- No Pix, mostrar total, chave e QR Code já cadastrados, permitir copiar a chave e abrir o WhatsApp com a mensagem solicitada; o estado continuará pendente até confirmação manual.
- Ao administrador marcar pagamento como pago, confirmar a degustação e remover o vencimento da reserva. Ao cancelar, liberar o horário preservando o histórico.
- Preservar orçamento, drinks, frete, mapa, agenda, datas, duração, endereço, autenticação, links e demais configurações.

## Alterações técnicas
- Não haverá nova tabela nem alteração de banco.
- A reserva será vinculada ao pagamento usando identificadores já existentes e metadados da sessão.
- O valor será validado no servidor a partir da própria reserva, evitando confiar no navegador.
- O checkout usará o ambiente de teste na prévia e o ambiente real somente após a ativação completa.

## Validação
- Verificar criação da reserva e as duas formas de pagamento.
- Confirmar que abrir o pagamento não muda os estados.
- Simular confirmação assinada e validar a transição para Pago/Confirmada.
- Confirmar Pix pendente, cópia da chave, QR Code e mensagem do WhatsApp.
- Verificar cancelamento e confirmação manual no painel.
